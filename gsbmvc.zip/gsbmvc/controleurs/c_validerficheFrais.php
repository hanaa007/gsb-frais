<?php

include("vues/v_comptable.php");
$action = $_REQUEST['action'];
$idVisiteur = $_SESSION['idVisiteur'];

switch ($action){
    case'selectionnerVisiteur':{
            $lesVisiteurs=$pdo->getLesVisiteurs();// Permet de selectionner les visiteurs
            $sixderniersmois=$pdo->getLesSixDerniersMois();// Permet de récupérer les six derniers mois en fonction de la date d'aujourd'hui
            include("vues/v_listeVisiteur.php");
	    break;
	}
        
        case'voirEtatFrais': {
            
            $lesVisiteurs=$pdo->getLesVisiteurs();
            $sixderniersmois=$pdo->getLesSixDerniersMois();
            $idVisiteur = isset($_REQUEST['lesvisiteurs']) ? $_REQUEST['lesvisiteurs'] : null;
            //print_r($idVisiteur);
            $leMois = isset($_REQUEST['lstMois']) ? $_REQUEST['lstMois'] : null; //Permet de définir une variable, si la variable existe 
            //et collecter des données du formulaire HTML à partir du request(valeur saisi par l'utilisateur)
            if ($idVisiteur && $leMois) {
                $_SESSION['lesvisiteurs'] = $idVisiteur; // Les variables sessions permettet de stocker les informations des utilisateurs.
                $_SESSION['lstMois'] = $leMois;
            }
            if(isset($_REQUEST['montantValide'])){
            $mois=$_SESSION['lstMois'];
            $etat='VA';
            $idVisiteur=$_SESSION['lesvisiteurs'];
            //print_r($mois);
            //print_r($idVisiteur);
            $pdo->calculerMontantvalide($idVisiteur,$mois);
            // Appel de la fonction pour calculer le montant
            $pdo->majEtatFicheFrais($idVisiteur,$mois,$etat);
            //Modifie l'état et la date de modification d'une fiche de frais, modifie le champ idEtat et met la date de modif à aujourd'hui
            }
            $moisASelectionner = $leMois;
            include("vues/v_listeVisiteur.php");
            $lesFraisHorsForfait = $pdo->getLesFraisHorsForfait($idVisiteur, $leMois);
            $lesFraisForfait = $pdo->getLesFraisForfait($idVisiteur, $leMois);
            $lesInfosFicheFrais = $pdo->getLesInfosFicheFrais($idVisiteur, $leMois);
            $numAnnee = substr($leMois, 0, 4);
            $numMois = substr($leMois, 4, 2);
            if(is_array($lesInfosFicheFrais)){
            $libEtat = $lesInfosFicheFrais['libEtat'];
            $montantValide = $lesInfosFicheFrais['montantValide'];
            $nbJustificatifs = $lesInfosFicheFrais['nbJustificatifs'];
            $dateModif = $lesInfosFicheFrais['dateModif'];
            $dateModif = dateAnglaisVersFrancais($dateModif);
            include("vues/v_etatFraisComp.php");}
            else{
            ajouterErreur("Pas de fiche de frais pour ce visiteur ce mois-ci.");
            include("vues/v_erreurs.php");
            }
            break;}
        
        case'modification':{ 
            
            ajouterConfirmation("les informations sont mises à jour");
            require("vues/v_confirmation.php");
            $lesVisiteurs=$pdo->getLesVisiteurs();
            $sixderniersmois=$pdo->getLesSixDerniersMois();
            $idVisiteur = isset($_REQUEST['lesvisiteurs']) ? $_REQUEST['lesvisiteurs'] : null;
            $leMois = isset($_REQUEST['lstMois']) ? $_REQUEST['lstMois'] : null;
            if ($idVisiteur && $leMois) {
                $_SESSION['lesvisiteurs'] = $idVisiteur;
                $_SESSION['lstMois'] = $leMois;
            }
            $moisASelectionner = $leMois;
            include("vues/v_listeVisiteur.php");
            $leMois =$_SESSION['lstMois'];
            $idVisiteur=$_SESSION['lesvisiteurs'];
            $lesFrais = $_REQUEST['lesFrais'];// Permet de récupérer, collecter les données du formulaire HTML.
            $pdo->majFraisForfait($idVisiteur, $leMois, $lesFrais);// Appel à la fonction qui permet de mettre
            // à jour la table ligneFraisForfait pour un visiteur et un mois donné en enregistrant les nouveaux montants
            $lesFraisHorsForfait = $pdo->getLesFraisHorsForfait($idVisiteur, $leMois);
            $lesFraisForfait = $pdo->getLesFraisForfait($idVisiteur, $leMois);
            $lesInfosFicheFrais = $pdo->getLesInfosFicheFrais($idVisiteur, $leMois);
            $numAnnee = substr($leMois, 0, 4);
            $numMois = substr($leMois, 4, 2);
            $libEtat = $lesInfosFicheFrais['libEtat'];
            $montantValide = $lesInfosFicheFrais['montantValide'];
            $nbJustificatifs = $lesInfosFicheFrais['nbJustificatifs'];
            $dateModif = $lesInfosFicheFrais['dateModif'];
            $dateModif = dateAnglaisVersFrancais($dateModif);
            include("vues/v_etatFraisComp.php");
            break;
        }
        
        case 'supprimer':{
            
     
            $id = $_REQUEST['id'];
            $mois=$_SESSION['lstMois'];
            $idVisiteur = $_SESSION["idVisiteur"];
            if ($_REQUEST['name'] == "Supprimer") {
            $pdo->refuserfrais($id);
            }
         
            
//        
//            
//            $idVisiteur=$_REQUEST['reporterFrais'];
//            $libelle=$_REQUEST['libelle'];
//            $montant=$_REQUEST['montant'];
//            $id=$_REQUEST['id'];
//            $leMois=$leMois+1;
//            if(substr($leMois,4,6)>=13){
//                $mois1=substr($leMois,4,6);
//                $mois1=$mois1-12;
//            if(strlen($mois1)<2){
//                $mois1="0".$mois1;
//                $annee1=substr($leMois,0,4)+1;
//            $leMois=$annee1.$mois1;}
//            }
//      
//    
//      $mois=$leMois;
//      if($pdo->getLesFraisForfait($idVisiteur,$leMois)==null){
//        $pdo->creeNouvellesLignesFrais($idVisiteur,$mois);
//        $pdo->reporterfrais($id,$idVisiteur,$leMois);
//      }else{
//        $pdo->reporterfrais($id,$idVisiteur,$leMois);
//      }
//break;}
//           
}
}
        
        
       
       
        

        

        

        
        
        
    



        
        
        
        
            
    
   
