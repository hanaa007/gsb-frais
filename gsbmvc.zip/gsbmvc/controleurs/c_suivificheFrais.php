<?php

include("vues/v_comptable.php");
$action = $_REQUEST['action'];
$idVisiteur = $_SESSION['idVisiteur'];

switch ($action){
    case'selectionnerfiche':{
            $listeFiche=$pdo->selectionFiche();// Fonction qui permet de récupérer les visiteurs qui ont validé leur fiche
            if($listeFiche==null){echo ajouterErreur("Il n'y a aucune fiche validée");
            include("vues/v_erreurs.php");}else{
            include("vues/v_listeFiche.php");}
	    break;
    }
    
        
        
       case'voirFrais': {
           
            $listeFiche=$pdo->selectionFiche();
            include("vues/v_listeFiche.php");
            $leMois = isset($_REQUEST['lstMois']) ? $_REQUEST['lstMois'] : null;//Permet de définir une variable, si la variable existe 
            //et collecter des données du formulaire HTML à partir du request(valeur saisi par l'utilisateur)
            $idVisiteur = $_SESSION['lesvisiteurs'];
            if ($idVisiteur && $leMois) {
                $_SESSION['lesvisiteurs'] = $idVisiteur;// Les variables sessions permettet de stocker les informations des utilisateurs.
                $_SESSION['lstMois'] = $leMois;         
            }
            //print_r($idVisiteur);
            $leMois = $_SESSION['lstMois']; 
            $lesMois=$pdo->getLesMoisDisponibles($idVisiteur);//Retourne les mois pour lesquel un visiteur a une fiche de frais
            $moisASelectionner = $leMois;
            $lesFraisHorsForfait = $pdo->getLesFraisHorsForfait($idVisiteur,$leMois);
            $lesFraisForfait= $pdo->getLesFraisForfait($idVisiteur,$leMois);
            $lesInfosFicheFrais = $pdo->getLesInfosFicheFrais($idVisiteur,$leMois);
            $numAnnee =substr( $leMois,0,4);
            $numMois =substr( $leMois,4,2);
            $libEtat = $lesInfosFicheFrais['libEtat'];
            $montantValide = $lesInfosFicheFrais['montantValide'];
            $nbJustificatifs = $lesInfosFicheFrais['nbJustificatifs'];
            $dateModif =  $lesInfosFicheFrais['dateModif'];
            $dateModif =  dateAnglaisVersFrancais($dateModif);
            include("vues/v_etatValidation.php");
            	if(isset($_REQUEST['rembourser'])){
                    $mois=$_SESSION['lstMois'];
                    $etat='RB';//quand idEtat est égal à RB
                $pdo->majEtatFicheFrais($idVisiteur,$mois,$etat);}////Modifie l'état et la date de modification d'une fiche de frais,
                // modifie le champ idEtat et met la date de modif à aujourd'hui
            }
            break;
       
}
