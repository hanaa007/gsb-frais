<div class ="confirme">
<ul>
<?php
foreach($_REQUEST['confirmation'] as $confirme)
        {
      echo "<li>$confirme</li>";
        }
?>
</ul></div>

