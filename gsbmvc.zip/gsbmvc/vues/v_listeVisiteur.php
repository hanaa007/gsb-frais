
      <div id="contenu"> 
      <h2>Validation des fiches de frais</h2>
   

      <form method="POST"  action="index.php?uc=validerficheFrais&action=voirEtatFrais">
          <div class="corpsForm">
         <fieldset>
              <legend>Visiteurs et mois à selectionner</legend>
              <label>Visiteur: </label>
              <select id="id" name="lesvisiteurs">
                  <?php 
                  
                        
                  foreach ($lesVisiteurs as $visiteur){
                      
                      $id=$visiteur['id'];
                      $nom=$visiteur['nom'];
                      $prenom=$visiteur['prenom'];
                     if ($id  ==  $_SESSION['id']){
                            ?>
                            <option  selected  value ="<?php echo $id;?>" > <?php echo $nom . " " . $prenom ?> </option>        
                        <?php } else {
                            ?>
                            <option  value ="<?php echo $id;?>" > <?php echo $nom . " " . $prenom ?> </option >        
                            <?php
                        }
                    }
                    ?>

                  
                  </select>
              <br><br>
              
                     <label  for = " lstMois " > Mois: </label>
                <select id= "lstMois"  name = "lstMois" >

           <?php
                        
                                               
             
                    $tableMois = $sixderniersmois['id'];
                    $i = 0; // initialisation à 0
                    foreach ($tableMois as $mois) {
                        if ($mois == $lesVisiteurs['id']) { // si le mois correspond a l'id du visiteur concerné
                            
                        } else {
                            ?>
                            <option value="<?php echo $mois; ?>"><?php echo $sixderniersmois['libelle'][$i]; ?></option>
                            
                            
                            <?php
                            // A chaque fois qu'on passe dans le foreach le $i s'incrémente , ensuite on affiche le numéro de case de la fonction les sixderniersmois
                            //correspondant au numéro du $i
                        }
                        $i++; 
                    }
                                  ?>   


                 
              
              
              </select>
          </div>
          
          
                  
      <div class="piedForm">
      <p>
        <input id="ok" type="submit" value="Valider" size="20" />
        <input id="annuler" type="reset" value="Effacer" size="20" />
      </p> 
         </fieldset>
      </div>
        
      </form>

              
              
         
      

      


      