
<ul>
<?php
	  $id = $_SESSION['idVisiteur'];
      echo "bonjour $id <a href='Deconnexion.php' >Deconnexion</a>";

?>
</ul>
