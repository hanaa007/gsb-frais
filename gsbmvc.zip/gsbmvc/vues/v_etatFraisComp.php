
<h3>Fiche de frais du mois <?php echo $numMois."-".$numAnnee ?> : 
</h3>

     <form action="index.php?uc=validerficheFrais&action=modification" method="post">
    <div class="encadre">

 <p>
        Etat : <?php echo $libEtat ?> depuis le <?php echo $dateModif  ?> <br> Montant validé : <?php echo $montantValide ?>


    </p>
        

    <table class="listeLegere">
        

        <caption>Eléments forfaitisés </caption>
        <tr>
            <?php
            ?>
            
            <?php
            foreach ($lesFraisForfait as $unFraisForfait) {
                $libelle = $unFraisForfait['libelle'];
                
                ?>         
                <th> <?php echo $libelle ?></th>
                <?php
            }
            ?>
        </tr>
        <tr>
            <?php
            foreach ($lesFraisForfait as $unFraisForfait) {
                $quantite = $unFraisForfait['quantite'];
                $idFraisForfait = $unFraisForfait['idfrais'];
                ?>
            <td class="qteForfait"><input type="number" name="lesFrais[<?php echo $idFraisForfait ?>]" size="10,5" value="<?php echo $quantite; ?>"/></td>
                <?php
            }
            ?>
        </tr>

        

    </table>
    <p align="right">
        <input id="ok" type="submit" value="Valider" size="20" />
        <input id="annuler" type="reset" value="Effacer" size="20" />
    </p> 
    </form>

 <table class="listeLegere">
        <caption>Descriptif des éléments hors forfait
            <input type="text" id="nbJustificatifs" name="leNbJustificatifs" size="10" maxlength="5"
            value="<?php echo $nbJustificatifs ?>" > justificatifs reçus </caption>

        </caption>
        <tr>
            <th class="date">Date</th>
            <th class="libelle">Libellé</th>
            <th class='montant'>Montant</th>  
            <th  colspan="2" style="text-align: center" >Action</th>
            
        </tr>
        
        <?php
foreach ($lesFraisHorsForfait as $unFraisHorsForfait) {
    $date = $unFraisHorsForfait['date'];
    $libelle = $unFraisHorsForfait['libelle'];
    $montant = $unFraisHorsForfait['montant'];
    $id=$unFraisHorsForfait['id'];
    
      
                    $refuse = 'REFUSE';
                    $pos1 = strncmp($refuse, $unFraisHorsForfait["libelle"], 6);//Compare les 2 chaînes en comparant les six premiers caractères du libellé
                    ?>

        <tr <?php
                    if ($pos1 == 0) { //0 si les deux chaînes sont égales, on affiche en rouge l'élément hors forfait.
                        echo ' class="rouge"' ;
                        
                    }
       
                    ?>>
            
            
        <form  action="index.php?uc=validerficheFrais&action=supprimer" method="POST">
            <input type="hidden" name="id" value="<?php echo $id ?>"/>
                <td><?php echo $date ?></td>
                <td><?php echo $libelle ?></td>
                <td><?php echo $montant ?></td>
                
                <td> <input
                            <?php if ($pos1 == 0) {
                            echo 'disabled="disabled"';//disabled est un attribut booléen, il spécifie que l'élément doit être désactivé. 
                            //Jusqu'à ce qu'une autre condition soit remplie pour rendre l'élément utilisable
                            }
                            ?>
                        id="ok" type="submit" name="name" value="Supprimer" size="20" /></td>
               <td> <input id="ok" type="submit"  name="name" value="Reporter" size="20" /></td>
                </form>
                
            </tr>
            
    <?php
}
?>
    </table>

    <p align="right">
        <form method="POST"  action="index.php?uc=validerficheFrais&action=voirEtatFrais">
        <input id="ok" type="submit" name="montantValide" value="Valider La Fiche" size="20" />
</form>
    </p>  

</div>
</div>


        
        
        
        
        
    
  
          
    