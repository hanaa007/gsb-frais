<div id="contenu">
    <h2> Bienvenue sur l'intranet Galaxy Swiss-Bourdin </h2>
    

